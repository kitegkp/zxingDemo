//
//  MultiFormatOneDReader.h
//  ZXingWidget
//
//  Created by Romain Pechayre on 6/14/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FormatReader.h"


@interface MultiFormatOneDReader : FormatReader {

}
- (id) init;
@end
