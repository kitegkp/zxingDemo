//
//  ViewController.m
//  gkptest004
//
//  Created by kitegkp on 15/6/1.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "ViewController.h"

#import "ZXingWidgetController.h"
#import "QRCodeReader.h"
#import "TwoDDecoderResult.h"


@interface ViewController ()<ZXingDelegate,DecoderDelegate,AVCaptureVideoDataOutputSampleBufferDelegate>
{
    NSMutableSet * _qrReader;
    BOOL _scanningQR;
    UIButton *_cancelButton;
    
    AVCaptureSession *_session;
    AVCaptureDeviceInput *_input;
    AVCaptureVideoDataOutput *_output;
    AVCaptureVideoPreviewLayer * _captureVideoPreviewLayer;
    
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIButton * tempBtn=[[UIButton alloc] initWithFrame:CGRectMake(30, 60, 100, 100)];
    [tempBtn setTitle:@"扫描" forState:UIControlStateNormal];
    [tempBtn addTarget:self action:@selector(scanPressed:) forControlEvents:UIControlEventTouchUpInside];
    [tempBtn setBackgroundColor:[UIColor redColor]];
    [self.view addSubview:tempBtn];
    
    UIButton * tempBtn0=[[UIButton alloc] initWithFrame:CGRectMake(30, 60+120, 100, 100)];
    [tempBtn0 setTitle:@"继续扫描" forState:UIControlStateNormal];
    [tempBtn0 addTarget:self action:@selector(scanPressed0:) forControlEvents:UIControlEventTouchUpInside];
    [tempBtn0 setBackgroundColor:[UIColor redColor]];
    [self.view addSubview:tempBtn0];
    
    
    _cancelButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [_cancelButton setTitle:@"cancel" forState:UIControlStateNormal];
    [_cancelButton setFrame:CGRectMake(30,60+120+120, 100,100)];
    [_cancelButton addTarget:self action:@selector(pressCancelButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_cancelButton];

}

- (void)pressCancelButton:(UIButton *)button
{
    [self stopCamera];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)scanPressed0:(id)sender {
    [self startCamera];
}


- (void)scanPressed:(id)sender {
    // 第一种二维码扫描方法
    
    
//    ZXingWidgetController *widController = [[ZXingWidgetController alloc] initWithDelegate:self showCancel:YES OneDMode:NO];
//    NSMutableSet *readers = [[NSMutableSet alloc ] init];
//    QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
//    [readers addObject:qrcodeReader];
//
//    widController.readers = readers;
//    [self presentViewController:widController animated:YES completion:^{
//        
//    }];
    
    //第二种方法
    _qrReader = [[NSMutableSet alloc ] init];
    QRCodeReader* qrcodeReader = [[QRCodeReader alloc] init];
    [_qrReader addObject:qrcodeReader];
    [self startCamera];
}

// AVFoundation的回调函数
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {
    // 第一步，将sampleBuffer转成UIImage
    UIImage *image= [self getCaptureImage:sampleBuffer];
    // 第二步，用Decoder识别图象
    Decoder *d = [[Decoder alloc] init];
    d.readers =_qrReader;
    d.delegate = self;
    _scanningQR= [d decodeImage:image] == YES ? NO : YES;
}

#pragma Supporting Methods
- (UIImage *) getCaptureImage:(CMSampleBufferRef) sampleBuffer
{
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
    // Lock the base address of the pixel buffer
    CVPixelBufferLockBaseAddress(imageBuffer,0);
    
    // Get the number of bytes per row for the pixel buffer
    size_t bytesPerRow = CVPixelBufferGetBytesPerRow(imageBuffer);
    // Get the pixel buffer width and height
    size_t width = CVPixelBufferGetWidth(imageBuffer);
    size_t height = CVPixelBufferGetHeight(imageBuffer);
    
    // Create a device-dependent RGB color space
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    if (!colorSpace)
    {
        NSLog(@"CGColorSpaceCreateDeviceRGB failure");
        return nil;
    }
    
    // Get the base address of the pixel buffer
    void *baseAddress = CVPixelBufferGetBaseAddress(imageBuffer);
    // Get the data size for contiguous planes of the pixel buffer.
    size_t bufferSize = CVPixelBufferGetDataSize(imageBuffer);

    
    
    // Create a Quartz direct-access data provider that uses data we supply
    CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, baseAddress, bufferSize,
                                                              NULL);
    // Create a bitmap image from data supplied by our data provider
    CGImageRef cgImage =
    CGImageCreate(width,
                  height,
                  8,
                  32,
                  bytesPerRow,
                  colorSpace,
                  kCGImageAlphaNoneSkipFirst | kCGBitmapByteOrder32Little,
                  provider,
                  NULL,
                  true,
                  kCGRenderingIntentDefault);
    CGDataProviderRelease(provider);
    CGColorSpaceRelease(colorSpace);
    
    // Create and return an image object representing the specified Quartz image
    UIImage *image = [UIImage imageWithCGImage:cgImage];
    CGImageRelease(cgImage);
    
    CVPixelBufferUnlockBaseAddress(imageBuffer, 0);
    
    return image;
}


- (void)initCapture
{
    if (!_session) {
        _session= [[AVCaptureSession alloc] init];
    }

    if (!_input) {
        AVCaptureDevice* inputDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        _input= [AVCaptureDeviceInput deviceInputWithDevice:inputDevice error:nil];
    }
    
    
    if ([_session canAddInput:_input]){
    [_session addInput:_input];
    }
    
    if (!_output) {
        _output = [[AVCaptureVideoDataOutput alloc] init];
        _output.alwaysDiscardsLateVideoFrames = YES;
        [_output setSampleBufferDelegate:self queue:dispatch_get_main_queue()];
        
        NSString* key = (NSString *)kCVPixelBufferPixelFormatTypeKey;
        NSNumber* value = [NSNumber numberWithUnsignedInt:kCVPixelFormatType_32BGRA];
        NSDictionary *videoSettings = [NSDictionary dictionaryWithObject:value forKey:key];
        [_output setVideoSettings:videoSettings];
    }
 
    if ([_session canAddOutput:_output]) {
        [_session addOutput:_output];
    }
    
    if (!_session.sessionPreset) {
        NSString* preset = 0;
        if (NSClassFromString(@"NSOrderedSet") && // Proxy for "is this iOS 5" ...
            [UIScreen mainScreen].scale > 1 &&
            [[_input device]
             supportsAVCaptureSessionPreset:AVCaptureSessionPresetiFrame960x540]) {
                // NSLog(@"960");
                preset = AVCaptureSessionPresetiFrame960x540;
            }
        if (!preset) {
            // NSLog(@"MED");
            preset = AVCaptureSessionPresetMedium;
        }
        _session.sessionPreset = preset;
    }

    if (!_captureVideoPreviewLayer) {
        _captureVideoPreviewLayer = [AVCaptureVideoPreviewLayer layerWithSession:_session];
        // NSLog(@"prev %p %@", self.prevLayer, self.prevLayer);
        _captureVideoPreviewLayer.frame = CGRectMake(100, 100, self.view.frame.size.width-120, self.view.frame.size.height-100*2);  //self.view.bounds;
        _captureVideoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
        [self.view.layer addSublayer: _captureVideoPreviewLayer];
    }
        [_session startRunning];
}


- (void) startCamera{
    _scanningQR=YES;
    [self initCapture];
}

- (void) stopCamera
{
     _scanningQR = NO;
    if (_session.isRunning) {
        [_session stopRunning];
        [_session removeInput:_input];
        [_session removeOutput:_output];
    }

}


#pragma mark- ZXingDelegate  -第一种方式时候
- (void)zxingController:(ZXingWidgetController*)controller didScanResult:(NSString *)result;
{
    NSLog(@"result %@",result);
    [self stopCamera];
}



- (void)zxingControllerDidCancel:(ZXingWidgetController*)controller{


}



#pragma mark -   DecoderDelegate
- (void)decoder:(Decoder *)decoder willDecodeImage:(UIImage *)image usingSubset:(UIImage *)subset{


}

- (void)decoder:(Decoder *)decoder didDecodeImage:(UIImage *)image usingSubset:(UIImage *)subset withResult:(TwoDDecoderResult *)result{

    [self stopCamera];

    NSLog(@"result = %@",[result text]);

}
- (void)decoder:(Decoder *)decoder failedToDecodeImage:(UIImage *)image usingSubset:(UIImage *)subset reason:(NSString *)reason{

    [self startCamera];
//
//    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"没有发现二维码" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
//    [alertView show];
//    [self stopCamera];
    
}


- (void)decoder:(Decoder *)decoder foundPossibleResultPoint:(CGPoint)point{
    
}



@end
